<html> 
<head> 
<title> 
Page not found  
</title> 
<style type="text/css">
body
{
background:#07c;
font-family:"calibri";
font-size:150%;
color:"#fff";
}
</style>
</head>

<body> 
<font color="#fff">

<h1> 
<center> 
<br><br> 
Requested page not found :P 
<br><br><br>
-Madhusudhan 
</center> 
</h1>
</font>
</body> 
</html> 