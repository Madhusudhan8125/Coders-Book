<?php

$db_con= mysqli("mysql4.000webhost.com","a2106918_coder","codersbook1","a2106918_code");
if(mysqli_connect_errno)
{
 echo mysqli_connect_error;
 exit();
 }
else
 echo " successfully connected" ;

?>